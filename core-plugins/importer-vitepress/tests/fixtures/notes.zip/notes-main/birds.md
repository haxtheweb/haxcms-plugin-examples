---
title: Birds of the marsh
---

::: info
Bring *binoculars*.
:::

![heron](./heron.jpg)
