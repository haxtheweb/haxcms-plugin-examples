import { generateSidebar } from './sidebar.js'
export default {
  title: 'Field Notes',
  themeConfig: { sidebar: generateSidebar() },
}
