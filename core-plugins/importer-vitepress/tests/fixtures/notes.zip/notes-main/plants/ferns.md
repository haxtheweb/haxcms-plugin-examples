Ferns like shade.
