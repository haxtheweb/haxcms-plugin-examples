Clean spills at once.
